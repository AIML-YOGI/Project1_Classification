File project1_1.ipynb is for Questions 1 through 6.
File project1_2.ipynb is for Questions 7.
File project1_3.ipynb is for Questions 8.
